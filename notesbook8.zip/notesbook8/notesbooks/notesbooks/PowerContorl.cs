﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace notesbooks
{
    class PowerContorl
    {
        private static string _name;

        public static string Name
        {
            get { return PowerContorl._name; }
            set { PowerContorl._name = value; }
        }
    }
}
