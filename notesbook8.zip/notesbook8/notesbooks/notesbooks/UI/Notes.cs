﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;



namespace notesbooks
{
    public partial class Notes : Form
    {/* 布尔变量b用于判断文件是新建的还是从磁盘打开的，
   true表示文件是从磁盘打开的，false表示文件是新建的，默认值为false*/
        bool b = false;
        /* 布尔变量s用于判断文件件是否被保存，
           true表示文件是已经被保存了，false表示文件未被保存，默认值为true*/
        bool s = true;
        string user;
        string olddir;
        string oldname;
        public void set(string u)
        {
            user = u;
        }

        public Notes()
        {
            InitializeComponent();
        }

        private void Notes_Load(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        private void close_Click_1(object sender, EventArgs e)//关闭界面
        {
            Application.Exit();
        }

        private void close_MouseEnter(object sender, EventArgs e)
        {
            close.SizeMode = PictureBoxSizeMode.CenterImage;
        }

        private void close_MouseLeave(object sender, EventArgs e)
        {
            close.SizeMode = PictureBoxSizeMode.Normal;
        }

        private void max_MouseClick(object sender, MouseEventArgs e)//最大化
        {
            this.WindowState = FormWindowState.Normal;
            max.Visible = true;
            max.Visible = false;
            this.MainForm_Load(sender, e);
        }

        private void MainForm_Load(object sender, EventArgs e)
        { }
        private void max_MouseEnter(object sender, EventArgs e)
        {
            max.SizeMode = PictureBoxSizeMode.CenterImage;
        }

        private void max_MouseLeave(object sender, EventArgs e)
        {
            max.SizeMode = PictureBoxSizeMode.Normal;
        }

        private void min_Click(object sender, EventArgs e)//最小化
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void min_MouseEnter(object sender, EventArgs e)
        {
            min.SizeMode = PictureBoxSizeMode.CenterImage;
        }

        private void min_MouseLeave(object sender, EventArgs e)
        {
            min.SizeMode = PictureBoxSizeMode.Normal;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void tsmiSave_MouseMove(object sender, MouseEventArgs e)
        {
            this.tsmiSave.BackColor = System.Drawing.Color.Gray;
        }

        private void tsmiSave_MouseLeave(object sender, EventArgs e)
        {
            this.tsmiSave.BackColor = this.BackColor;
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)//保存对话框
        {

        }

        private void openFileDialog_FileOk(object sender, CancelEventArgs e)//打开对话框
        {

        }

        private void tsmiFont_Click(object sender, EventArgs e)//设置字体
        {
            fdlgNotepad.ShowColor = true;
            if (fdlgNotepad.ShowDialog() == DialogResult.OK)
            {
                rtxtNotepad.SelectionColor = fdlgNotepad.Color;
                rtxtNotepad.SelectionFont = fdlgNotepad.Font;
            }
        }

        private void rtxtNotepad_TextChanged(object sender, EventArgs e)//多格式文本框
        {
            s = false;
        }

        private void tsmiUndo_Click(object sender, EventArgs e)//撤销
        {
            rtxtNotepad.Undo();
        }

        private void tsmiRedo_Click(object sender, EventArgs e)//恢复
        {
            rtxtNotepad.Redo();
        }

        private void tsmiUndo_MouseMove(object sender, EventArgs e)
        {
            this.tsmiUndo.BackColor = System.Drawing.Color.Gray;
        }

        private void tsmiUndo_MouseLeave(object sender, EventArgs e)
        {
            this.tsmiUndo.BackColor = this.BackColor;
        }
        private void tsmiRedo_MouseMove(object sender, EventArgs e)
        {
            this.tsmiRedo.BackColor = System.Drawing.Color.Gray;
        }

        private void tsmiRedo_MouseLeave(object sender, EventArgs e)
        {
            this.tsmiRedo.BackColor = this.BackColor;
        }

        private void ClearText(Control ctrlTop)
        {
            if (ctrlTop.GetType() == typeof(RichTextBox))
                ctrlTop.Text = "";
            else
            {
                foreach (Control ctrl in ctrlTop.Controls)
                {
                    ClearText(ctrl); //循环调用  
                }
            }
        }

        private void tsmiNew_Click(object sender, EventArgs e)//新建笔记
        {
            // 判断当前文件是否从磁盘打开，或者新建时文档不为空，并且文件未被保存
            if (b == true || rtxtNotepad.Text.Trim() != "")
            {
                // 若文件未保存
                if (s == false)
                {
                    string result;
                    result = MessageBox.Show("文件尚未保存,是否保存?",
                        "保存文件", MessageBoxButtons.YesNoCancel).ToString();
                    switch (result)
                    {
                        case "Yes":
                            // 若文件是从磁盘打开的
                            if (b == true)
                            {
                                //按文件打开的路径保存文件
                                rtxtNotepad.SaveFile(odlgNotepad.FileName);
                            }
                            //若文件不是从磁盘打开的
                            else
                                if (sdlgNotepad.ShowDialog() == DialogResult.OK)
                                {
                                    rtxtNotepad.SaveFile(sdlgNotepad.FileName);
                                }
                            s = true;
                            rtxtNotepad.Text = "";
                            break;
                        case "No":
                            b = false;
                            rtxtNotepad.Text = "";
                            break;
                    }
                }
            }
            ClearText(this);
        }



        private void tsmiCopy_Click(object sender, EventArgs e)
        {

        }


        private void tsmiPaste_Click(object sender, EventArgs e)
        {
            rtxtNotepad.Paste();
        }

        private void tsmiSelectAll_Click(object sender, EventArgs e)//全选
        {

            rtxtNotepad.Focus();//设置定位到当前活动的RichTextBox,  
            rtxtNotepad.SelectAll();

        }
        private void tsmiSelectAll_MouseMove(object sender, EventArgs e)
        {
            this.tsmiSelectAll.BackColor = System.Drawing.Color.Gray;
        }

        private void tsmiSelectAll_MouseLeave(object sender, EventArgs e)
        {
            this.tsmiSelectAll.BackColor = this.BackColor;
        }

        private void tlsNotepad_ItemClicked(object sender, ToolStripItemClickedEventArgs e)//单击事件
        {
            {
                int n;
                // 变量n用来接收按下按钮的索引号
                n = tlsNotepad.Items.IndexOf(e.ClickedItem);
                switch (n)
                {
                    case 0:
                       Open_Click(sender, e);
                        break;
                    case 1:
                        tsmiSaveAs_Click(sender, e);
                        break;
                    case 2:
                        tsmiCut_Click(sender, e);
                        break;
                    case 3:
                        tsmiCopy_Click(sender, e);
                        break;
                    case 4:
                        tsmiPaste_Click(sender, e);
                        break;
                    case 5:
                        tsmiUndo_Click(sender, e);
                        break;
                    case 6:
                        tsmiRedo_Click(sender, e);
                        break;
                    case 7:
                        tsmiFont_Click(sender, e);
                        break;
                    case 8:
                        Bold_Click(sender, e);
                        break;
                    case 9:
                        Italic_Click(sender, e);
                        break;
                    case 10:
                        underline_Click(sender, e);
                        break;
                    case 11:
                        Backgroundclr_Click(sender, e);
                        break;
                    case 12:
                        tsmiSelectAll_Click(sender, e);
                        break;
                    case 13:
                        tsmiAuto_Click(sender, e);
                        break;
                }
            }
        }

        private void tsmiCut_Click(object sender, EventArgs e)//剪切
        {
            rtxtNotepad.Cut();
        }



        private void tsmiAuto_Click(object sender, EventArgs e)//自动换行
        {
            if (tsmiAuto.Checked == false)
            {
                tsmiAuto.Checked = true;        	// 选中该菜单项
                rtxtNotepad.WordWrap = true;       	// 设置为自动换行
            }
            else
            {
                tsmiAuto.Checked = false;
                rtxtNotepad.WordWrap = false;
            }

        }


        private void tsmiOpen_Click(object sender, EventArgs e)//打开笔记
        {
            if (b == true || rtxtNotepad.Text.Trim() != "")
            {
                if (s == false)
                {
                    string result;
                    result = MessageBox.Show("文件尚未保存,是否保存?",
                      "保存文件", MessageBoxButtons.YesNoCancel).ToString();
                    switch (result)
                    {
                        case "Yes":
                            if (b == true)
                            {
                                rtxtNotepad.SaveFile(odlgNotepad.FileName);
                            }
                            else if (sdlgNotepad.ShowDialog() == DialogResult.OK)
                            {
                                rtxtNotepad.SaveFile(sdlgNotepad.FileName);
                            }
                            s = true;
                            break;
                        case "No":
                            b = false;
                            rtxtNotepad.Text = "";
                            break;
                    }
                }
            }
            odlgNotepad.RestoreDirectory = true;
            if ((odlgNotepad.ShowDialog() == DialogResult.OK) && odlgNotepad.FileName != "")
            {
                rtxtNotepad.LoadFile(odlgNotepad.FileName);
                b = true;
            }
            s = true;
        }

        private void Backgroundclr_Click(object sender, EventArgs e)//设置背景颜色
        {
            colorDialog1.ShowDialog();
            this.rtxtNotepad.BackColor = this.colorDialog1.Color;
        }

        private void tsmiSave_Click(object sender, EventArgs e)//保存
        {
            // 若文件从磁盘打开并且修改了其内容
            if (b == true && rtxtNotepad.Modified == true)
            {
                rtxtNotepad.SaveFile(odlgNotepad.FileName);
                s = true;
            }
            else if (b == false && rtxtNotepad.Text.Trim() != "" &&
                sdlgNotepad.ShowDialog() == DialogResult.OK)
            {
                rtxtNotepad.SaveFile(sdlgNotepad.FileName);
                s = true;
                b = true;
                odlgNotepad.FileName = sdlgNotepad.FileName;
            }
        }

        private void tsmiSaveAs_Click(object sender, EventArgs e)//另存为
        {
            if (sdlgNotepad.ShowDialog() == DialogResult.OK)
            {
                rtxtNotepad.SaveFile(sdlgNotepad.FileName);
                s = true;
            }
        }



        private void Bold_Click(object sender, EventArgs e)//加粗
        {
            Font oldFont = this.rtxtNotepad.SelectionFont;
            Font newFont;

            if (oldFont.Bold)
                newFont = new Font(oldFont, oldFont.Style & ~FontStyle.Bold);

            else
                newFont = new Font(oldFont, oldFont.Style | FontStyle.Bold);

            this.rtxtNotepad.SelectionFont = newFont;
            this.rtxtNotepad.Focus();
        }

        private void Italic_Click(object sender, EventArgs e)//斜体
        {
            Font oldFont = this.rtxtNotepad.SelectionFont;
            Font newFont;

            if (oldFont.Italic)
                newFont = new Font(oldFont, oldFont.Style & ~FontStyle.Italic);

            else
                newFont = new Font(oldFont, oldFont.Style | FontStyle.Italic);

            this.rtxtNotepad.SelectionFont = newFont;
            this.rtxtNotepad.Focus();
        }

        private void underline_Click(object sender, EventArgs e)//下划线
        {
            Font oldFont = this.rtxtNotepad.SelectionFont;
            Font newFont;

            if (oldFont.Underline)
                newFont = new Font(oldFont, oldFont.Style & ~FontStyle.Underline);

            else
                newFont = new Font(oldFont, oldFont.Style | FontStyle.Underline);

            this.rtxtNotepad.SelectionFont = newFont;

            this.rtxtNotepad.Focus();
        }

        private void classify_Opening(object sender, CancelEventArgs e)
        {

        }

        private void 新建分类_Click(object sender, EventArgs e)
        {
            Classifyname _Classifyname = new Classifyname();
            _Classifyname.Show();


        }

        private void 修改分类_Click(object sender, EventArgs e)
        {
            REClassifyname _REClassifyname = new REClassifyname();
            _REClassifyname.Show();
        }



        private void 新建_Click(object sender, EventArgs e)//新建笔记
        {
            // 判断当前文件是否从磁盘打开，或者新建时文档不为空，并且文件未被保存
            if (b == true || rtxtNotepad.Text.Trim() != "")
            {
                // 若文件未保存
                if (s == false)
                {
                    string result;
                    result = MessageBox.Show("文件尚未保存,是否保存?",
                        "保存文件", MessageBoxButtons.YesNoCancel).ToString();
                    switch (result)
                    {
                        case "Yes":
                            // 若文件是从磁盘打开的
                            if (b == true)
                            {
                                //按文件打开的路径保存文件
                                rtxtNotepad.SaveFile(odlgNotepad.FileName);
                            }
                            //若文件不是从磁盘打开的
                            else
                                if (sdlgNotepad.ShowDialog() == DialogResult.OK)
                                {
                                    rtxtNotepad.SaveFile(sdlgNotepad.FileName);
                                }
                            s = true;
                            rtxtNotepad.Text = "";
                            break;
                        case "No":
                            b = false;
                            rtxtNotepad.Text = "";
                            break;
                    }
                }
            }
            ClearText(this);

        }

        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)//设置结点
        {
            //string path = "C:\\Users\\Administrator\\Desktop\\Note\\";
            //PaintTreeView(treeView, path);
            if (treeView.SelectedNode.Parent != null)
                olddir = treeView.SelectedNode.Parent.FullPath.ToString();
            else
                olddir = "";
            oldname = treeView.SelectedNode.Text;
        }
        private void function_page_Load(object sender, EventArgs e)
        {

            string path = "C:\\Users\\Administrator\\Desktop\\Note\\";
            PaintTreeView(treeView, path);
        }

        private void PaintTreeView(TreeView treeView, string fullPath)
        {
            try
            {
                treeView.Nodes.Clear();
                DirectoryInfo dirs = new DirectoryInfo(fullPath);
                DirectoryInfo[] dir = dirs.GetDirectories();
                FileInfo[] file = dirs.GetFiles();
                int dircount = dir.Count();
                int filecount = file.Count();

                for (int i = 0; i < dircount; i++)
                {
                    TreeNode root = treeView.Nodes.Add(dir[i].Name);
                    root.ContextMenuStrip = NEWmenu2;
                    string pathNode = fullPath + "\\" + dir[i].Name;
                    GetMultiNode(treeView.Nodes[i], pathNode);
                }
                for (int j = 0; j < filecount; j++)
                {
                    TreeNode root = treeView.Nodes.Add(file[j].Name);
                    root.ContextMenuStrip = NEWmenu2;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private bool GetMultiNode(TreeNode treeNode, string path)
        {
            if (Directory.Exists(path) == false)
            {
                return false;
            }

            DirectoryInfo dirs = new DirectoryInfo(path);
            DirectoryInfo[] dir = dirs.GetDirectories();
            FileInfo[] file = dirs.GetFiles();
            int dircount = dir.Count();
            int filecount = file.Count();
            int sumcount = dircount + filecount;
            if (sumcount == 0)
            {
                return false;
            }
            for (int j = 0; j < dircount; j++)
            {
                TreeNode root = treeNode.Nodes.Add(dir[j].Name);
                string pathNodeB = path + "\\" + dir[j].Name;
                GetMultiNode(treeNode.Nodes[j], pathNodeB);

            }
            for (int j = 0; j < filecount; j++)
            {
                TreeNode root = treeNode.Nodes.Add(file[j].Name);

            }
            return true;
        }

        private void 重命名_Click(object sender, EventArgs e)
        {
            string path = "C:\\Users\\Administrator\\Desktop\\Note\\";
            rename _rename = new rename(path,olddir, oldname);
            _rename.Show();
        }

        private void 删除分类_Click(object sender, EventArgs e)
        {
            Delete _Delete = new Delete();
            _Delete.Show();
        }

        private void 移动到ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Move _Move = new Move();
            _Move.Show();
        }

        private void 打开ToolStripMenuItem_DoubleClick(object sender, EventArgs e)
        {
            string path = "C:\\Users\\Administrator\\Desktop\\Note\\";
            string path2 = path + "\\" + @treeView.SelectedNode.FullPath;
            rtxtNotepad.LoadFile(path2, RichTextBoxStreamType.RichText);

        }

        private void 删除_Click(object sender, EventArgs e)
        {
             //Delete2 _Delete2 = new Delete2();
            //_Delete2.Show();  


            if (MessageBox.Show("确定删除？", "删除", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                string path = "C:\\Users\\Administrator\\Desktop\\Note\\" + treeView.SelectedNode.FullPath;
                Directory.Delete(path);
                treeView1.SelectedNode.Remove();

            }
            MessageBox.Show("删除成功");

        }

        private void treeView_MouseUp(object sender, MouseEventArgs e)
        {
        }

        private void treeView_MouseDown(object sender, MouseEventArgs e)
        {
         

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            string path = "C:\\Users\\Administrator\\Desktop\\Note\\";
            PaintTreeView(treeView, path);
        }

        private void 打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (b == true || rtxtNotepad.Text.Trim() != "")
            {
                if (s == false)
                {
                    string result;
                    result = MessageBox.Show("文件尚未保存,是否保存?",
                      "保存文件", MessageBoxButtons.YesNoCancel).ToString();
                    switch (result)
                    {
                        case "Yes":
                            if (b == true)
                            {
                                rtxtNotepad.SaveFile(odlgNotepad.FileName);
                            }
                            else if (sdlgNotepad.ShowDialog() == DialogResult.OK)
                            {
                                rtxtNotepad.SaveFile(sdlgNotepad.FileName);
                            }
                            s = true;
                            break;
                        case "No":
                            b = false;
                            rtxtNotepad.Text = "";
                            break;
                    }
                }
            }
            odlgNotepad.RestoreDirectory = true;
            if ((odlgNotepad.ShowDialog() == DialogResult.OK) && odlgNotepad.FileName != "")
            {
                rtxtNotepad.LoadFile(odlgNotepad.FileName);
                b = true;
            }
            s = true;
        }


        private void Open_Click(object sender, EventArgs e)
        {
            if (b == true || rtxtNotepad.Text.Trim() != "")
            {
                if (s == false)
                {
                    string result;
                    result = MessageBox.Show("文件尚未保存,是否保存?",
                      "保存文件", MessageBoxButtons.YesNoCancel).ToString();
                    switch (result)
                    {
                        case "Yes":
                            if (b == true)
                            {
                                rtxtNotepad.SaveFile(odlgNotepad.FileName);
                            }
                            else if (sdlgNotepad.ShowDialog() == DialogResult.OK)
                            {
                                rtxtNotepad.SaveFile(sdlgNotepad.FileName);
                            }
                            s = true;
                            break;
                        case "No":
                            b = false;
                            rtxtNotepad.Text = "";
                            break;
                    }
                }
            }
            odlgNotepad.RestoreDirectory = true;
            if ((odlgNotepad.ShowDialog() == DialogResult.OK) && odlgNotepad.FileName != "")
            {
                rtxtNotepad.LoadFile(odlgNotepad.FileName);
                b = true;
            }
            s = true;
        }

        private void tsmiCopy_Click_1(object sender, EventArgs e)
        {

        }

        private void tsmiPaste_Click_1(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

      
    }
}
        

        
  



    


   
    

