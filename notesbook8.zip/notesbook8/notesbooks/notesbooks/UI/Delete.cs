﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace notesbooks
{
    public partial class Delete : Form
    {
        public Delete()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = "C:\\Users\\Administrator\\Desktop\\Note\\";
            DirectoryInfo dire = new DirectoryInfo(path  + textBox1.Text);
            foreach (FileInfo fi in dire.GetFiles())
            {

                fi.Delete();

            }
            Directory.Delete(path + textBox1.Text);
            MessageBox.Show("删除成功！");
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
             this.Close();
        }

        private void Delete_Load(object sender, EventArgs e)
        {

        }

     
    }
}
