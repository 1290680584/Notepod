﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace notesbooks
{
    public partial class Move : Form
    {
        public Move()
        {
            InitializeComponent();
        }
      
        private void button1_Click(object sender, EventArgs e)
        {
            string path = "C:\\Users\\Administrator\\Desktop\\Note\\";
            //string move_note = Console.ReadLine();
            //string move_classity = Console.ReadLine();
            Directory.Move(path + textBox1.Text, path + textBox2.Text + "\\" +textBox1.Text);
            //File.Copy(path + textBox1.Text , path + textBox2.Text );
            //Directory.Delete(path + textBox1.Text);
            //File.Delete(path + textBox1.Text);
            MessageBox.Show("移动成功！");
            this.Close();

        }
        
        private void CopyDirectory(string p, string p_2)
        {
            throw new NotImplementedException();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Move_Load(object sender, EventArgs e)
        {

        }

       
    }
}
