﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace notesbooks
{
    public partial class REClassifyname : Form
    {
        public REClassifyname()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = "C:\\Users\\Administrator\\Desktop\\Note\\";

            Directory.CreateDirectory(path + textBox2.Text);
            
            foreach(FileInfo fi in new DirectoryInfo(path  + textBox1.Text).GetFiles())
            {
                fi.CopyTo(path  + textBox2.Text + fi.ToString());
                fi.Delete();
            }
            Directory.Delete(path + textBox1.Text);
            MessageBox.Show("修改成功");
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void REClassifyname_Load(object sender, EventArgs e)
        {

        }
    }
}
