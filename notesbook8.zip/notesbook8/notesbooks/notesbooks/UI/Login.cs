﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.Sql;

namespace notesbooks
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Register Register = new Register();
            Register.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            int flag = 0;
            string ConnectionString = Properties.Settings.Default.notebook1ConnectionString;
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn.ConnectionString = ConnectionString;
                sqlconn.Open();
                SqlCommand sqlcomm = new SqlCommand();
                sqlcomm.Connection = sqlconn;
                sqlcomm.CommandText = "select userid,userpassword from db_User";
                SqlDataReader dr = sqlcomm.ExecuteReader();
                while (dr.Read())
                {
                    string LJuser;
                    string LJpwd;
                    LJuser = dr["userid"].ToString();
                    LJpwd = dr["UserPassword"].ToString();
                    if (dr["userid"].ToString().Trim() == USERNAME.Text && dr["UserPassword"].ToString().Trim() == USERPWD.Text)
                    {

                        flag = 1;
                        Notes notes = new Notes();
                        notes.set(LJuser);
                        MessageBox.Show("登录成功");
                        Notes _Notes = new Notes();
                        _Notes.Show();
                        if (!dr.IsClosed)
                        {
                            dr.Close();

                        }
                        break;

                    }

                }
                if (flag == 0)
                { MessageBox.Show("您输入的账号或者密码不正确"); }

            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
            finally
            {
                if (sqlconn != null && sqlconn.State == ConnectionState.Open)
                { sqlconn.Close(); }

            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Reset _Reset = new Reset();
            _Reset.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            logins _logins = new logins();
            _logins.Show();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void picclose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void picclose_MouseEnter(object sender, EventArgs e)
        {
            picclose.SizeMode = PictureBoxSizeMode.Normal;
        }

        private void picclose_MouseLeave(object sender, EventArgs e)
        {
            picclose.SizeMode = PictureBoxSizeMode.Normal;
        }

        private void USERNAME_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
