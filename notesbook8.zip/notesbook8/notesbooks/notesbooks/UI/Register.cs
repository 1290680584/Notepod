﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.Sql;

namespace notesbooks
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login Login = new Login();
            Login.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ConnectionString = Properties.Settings.Default.notebook1ConnectionString;
            SqlConnection sqlconn = new SqlConnection();
            try
            {
                sqlconn.ConnectionString = ConnectionString;
                sqlconn.Open();
                SqlCommand sqlcomm = new SqlCommand();
                sqlcomm.Connection = sqlconn;
                if (renewpwd.Text == newpwd.Text)
                {
                    sqlcomm.CommandText = "insert into  db_User (UserID,UserPassword,UserPhone) values(@id,@pwd,@phone)";
                    // SqlDataReader dr = sqlcomm.ExecuteReader();
                    SqlParameter phone = new SqlParameter("@phone", SqlDbType.NVarChar, 50);
                    SqlParameter id = new SqlParameter("@id", SqlDbType.NVarChar, 50);
                    SqlParameter pwd = new SqlParameter("@pwd", SqlDbType.NVarChar, 50);

                    phone.Value = newphone.Text;
                    id.Value = userid.Text;
                    pwd.Value = newpwd.Text;
                    sqlcomm.Parameters.Add(phone);
                    sqlcomm.Parameters.Add(id);
                    sqlcomm.Parameters.Add(pwd);



                    if (sqlcomm.ExecuteNonQuery() != 0)
                    {
                        MessageBox.Show("注册成功");



                    }
                    else { MessageBox.Show("注册失败"); }
                }
                else
                    { MessageBox.Show("密码不一致请重新输入"); }
            }
           

            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
            finally
            {
                if (sqlconn != null && sqlconn.State == ConnectionState.Open)
                { sqlconn.Close(); }

            }
            Login Login = new Login();
            Login.Show();
            this.Dispose();
            this.Close();

        }

        private void newpwd_TextChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
       
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
