﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Data.Sql;

namespace notesbooks
{
    public partial class Reset : Form
    {
        public Reset()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login _Login = new Login();
            _Login.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("暂未实现此功能");
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // int flag = 0;
            string ConnectionString = Properties.Settings.Default.notebook1ConnectionString;
            SqlConnection sqlconn = new SqlConnection();
            try
            {

                sqlconn.ConnectionString = ConnectionString;
                sqlconn.Open();
                SqlCommand sqlcomm = new SqlCommand();
                sqlcomm.Connection = sqlconn;
                sqlcomm.CommandText = "select * from db_User";
                SqlDataReader dr = sqlcomm.ExecuteReader();
                while (dr.Read())
                {


                    string LJuser;
                    string LJphone;
                    LJuser = dr["UserID"].ToString();
                    LJphone = dr["UserPhone"].ToString();

                    if (dr["UserID"].ToString().Trim()== REID.Text &&dr["UserPhone"].ToString().Trim()== REPHONE.Text)
                    {

                        if (REREPWD.Text == REPWD.Text)
                        {
                            if (sqlconn != null && sqlconn.State == ConnectionState.Open)
                            {
                                sqlconn.Close();
                                sqlcomm = null;
                                SqlConnection sqlconn2 = new SqlConnection();
                                sqlconn2.ConnectionString = ConnectionString;
                                sqlconn2.Open();
                                SqlCommand sqlcomm2 = new SqlCommand();
                                sqlcomm2.Connection = sqlconn2;
                                sqlcomm2.CommandText = "update [db_User] set UserPassword = @newpwd where UserID = @userid ";
                                SqlParameter newpwd = new SqlParameter("@newpwd", SqlDbType.NVarChar, 50);
                                SqlParameter userid = new SqlParameter("@userid", SqlDbType.NVarChar, 50);
                                newpwd.Value = REREPWD.Text;
                                userid.Value = REID.Text;
                                sqlcomm2.Parameters.Add(userid);
                                sqlcomm2.Parameters.Add(newpwd);
                                if (sqlcomm2.ExecuteNonQuery() != 0)
                                {

                                    MessageBox.Show("修改成功");
                                    sqlconn2.Close();
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("密码重复不正确");
                        }
                    }
                    else { MessageBox.Show("验证手机号输入错误"); }


                    break;
                }
            }



            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
            finally
            {
                if (sqlconn != null && sqlconn.State == ConnectionState.Open)
                { sqlconn.Close(); }

            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
