﻿namespace notesbooks
{
    partial class Notes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Notes));
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("提到我的消息");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("笔记被修改的消息");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("评论消息");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("我发出的消息");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("消息中心", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4});
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("拖动笔记，文件夹，标签等加到快捷方式");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("快捷方式", new System.Windows.Forms.TreeNode[] {
            treeNode6});
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("快速搜索");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("我的文件");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("其他");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("文件夹", new System.Windows.Forms.TreeNode[] {
            treeNode9,
            treeNode10});
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("我的笔记");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("我的草稿");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("回收站");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("文件夹", new System.Windows.Forms.TreeNode[] {
            treeNode12,
            treeNode13,
            treeNode14});
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("标签");
            this.NEWmenu2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.打开ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新建 = new System.Windows.Forms.ToolStripMenuItem();
            this.删除 = new System.Windows.Forms.ToolStripMenuItem();
            this.重命名 = new System.Windows.Forms.ToolStripMenuItem();
            this.classify = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.新建分类 = new System.Windows.Forms.ToolStripMenuItem();
            this.修改分类 = new System.Windows.Forms.ToolStripMenuItem();
            this.删除分类 = new System.Windows.Forms.ToolStripMenuItem();
            this.移动到ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.min = new System.Windows.Forms.PictureBox();
            this.max = new System.Windows.Forms.PictureBox();
            this.close = new System.Windows.Forms.PictureBox();
            this.NewMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmiNew = new System.Windows.Forms.ToolStripMenuItem();
            this.桌面便签 = new System.Windows.Forms.ToolStripMenuItem();
            this.MarkDown笔记 = new System.Windows.Forms.ToolStripMenuItem();
            this.分类 = new System.Windows.Forms.ToolStripSeparator();
            this.我的日记 = new System.Windows.Forms.ToolStripMenuItem();
            this.会议记录 = new System.Windows.Forms.ToolStripMenuItem();
            this.工作日志 = new System.Windows.Forms.ToolStripMenuItem();
            this.九宫格日志 = new System.Windows.Forms.ToolStripMenuItem();
            this.客户拜访日记 = new System.Windows.Forms.ToolStripMenuItem();
            this.工作周报 = new System.Windows.Forms.ToolStripMenuItem();
            this.更多模板 = new System.Windows.Forms.ToolStripMenuItem();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.treeView = new System.Windows.Forms.TreeView();
            this.treeView11 = new System.Windows.Forms.TreeView();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rtxtNotepad = new System.Windows.Forms.RichTextBox();
            this.tsmiSave = new System.Windows.Forms.Button();
            this.sdlgNotepad = new System.Windows.Forms.SaveFileDialog();
            this.odlgNotepad = new System.Windows.Forms.OpenFileDialog();
            this.fdlgNotepad = new System.Windows.Forms.FontDialog();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.tsmiOpen = new System.Windows.Forms.Button();
            this.tlsNotepad = new System.Windows.Forms.ToolStrip();
            this.Open = new System.Windows.Forms.ToolStripButton();
            this.tsmiSaveAs = new System.Windows.Forms.ToolStripButton();
            this.tsmiCut = new System.Windows.Forms.ToolStripButton();
            this.tsmiCopy = new System.Windows.Forms.ToolStripButton();
            this.tsmiPaste = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiUndo = new System.Windows.Forms.ToolStripButton();
            this.tsmiRedo = new System.Windows.Forms.ToolStripButton();
            this.tsmiFont = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.粗体 = new System.Windows.Forms.ToolStripButton();
            this.Italic = new System.Windows.Forms.ToolStripButton();
            this.underline = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.Backgroundclr = new System.Windows.Forms.ToolStripButton();
            this.tsmiSelectAll = new System.Windows.Forms.ToolStripButton();
            this.tsmiAuto = new System.Windows.Forms.ToolStripButton();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.label7 = new System.Windows.Forms.Label();
            this.NEWmenu2.SuspendLayout();
            this.classify.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.min)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.max)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.close)).BeginInit();
            this.NewMenu.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.tlsNotepad.SuspendLayout();
            this.SuspendLayout();
            // 
            // NEWmenu2
            // 
            this.NEWmenu2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.打开ToolStripMenuItem,
            this.新建,
            this.删除,
            this.重命名});
            this.NEWmenu2.Name = "contextMenuStrip1";
            this.NEWmenu2.ShowImageMargin = false;
            this.NEWmenu2.Size = new System.Drawing.Size(99, 100);
            // 
            // 打开ToolStripMenuItem
            // 
            this.打开ToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.打开ToolStripMenuItem.Name = "打开ToolStripMenuItem";
            this.打开ToolStripMenuItem.Size = new System.Drawing.Size(98, 24);
            this.打开ToolStripMenuItem.Text = "打开";
            this.打开ToolStripMenuItem.Click += new System.EventHandler(this.打开ToolStripMenuItem_Click);
            this.打开ToolStripMenuItem.DoubleClick += new System.EventHandler(this.打开ToolStripMenuItem_DoubleClick);
            // 
            // 新建
            // 
            this.新建.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.新建.Name = "新建";
            this.新建.Size = new System.Drawing.Size(98, 24);
            this.新建.Text = "新建";
            this.新建.Click += new System.EventHandler(this.新建_Click);
            // 
            // 删除
            // 
            this.删除.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.删除.Name = "删除";
            this.删除.Size = new System.Drawing.Size(98, 24);
            this.删除.Text = "删除";
            this.删除.Click += new System.EventHandler(this.删除_Click);
            // 
            // 重命名
            // 
            this.重命名.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.重命名.Name = "重命名";
            this.重命名.Size = new System.Drawing.Size(98, 24);
            this.重命名.Text = "重命名";
            this.重命名.Click += new System.EventHandler(this.重命名_Click);
            // 
            // classify
            // 
            this.classify.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新建分类,
            this.修改分类,
            this.删除分类,
            this.移动到ToolStripMenuItem});
            this.classify.Name = "contextMenuStrip1";
            this.classify.ShowImageMargin = false;
            this.classify.Size = new System.Drawing.Size(114, 100);
            this.classify.Text = "classify";
            this.classify.Opening += new System.ComponentModel.CancelEventHandler(this.classify_Opening);
            // 
            // 新建分类
            // 
            this.新建分类.Name = "新建分类";
            this.新建分类.Size = new System.Drawing.Size(113, 24);
            this.新建分类.Text = "新建分类";
            this.新建分类.Click += new System.EventHandler(this.新建分类_Click);
            // 
            // 修改分类
            // 
            this.修改分类.Name = "修改分类";
            this.修改分类.Size = new System.Drawing.Size(113, 24);
            this.修改分类.Text = "修改分类";
            this.修改分类.Click += new System.EventHandler(this.修改分类_Click);
            // 
            // 删除分类
            // 
            this.删除分类.Name = "删除分类";
            this.删除分类.Size = new System.Drawing.Size(113, 24);
            this.删除分类.Text = "删除分类";
            this.删除分类.Click += new System.EventHandler(this.删除分类_Click);
            // 
            // 移动到ToolStripMenuItem
            // 
            this.移动到ToolStripMenuItem.Name = "移动到ToolStripMenuItem";
            this.移动到ToolStripMenuItem.Size = new System.Drawing.Size(113, 24);
            this.移动到ToolStripMenuItem.Text = "移动到";
            this.移动到ToolStripMenuItem.Click += new System.EventHandler(this.移动到ToolStripMenuItem_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.min);
            this.panel3.Controls.Add(this.max);
            this.panel3.Controls.Add(this.close);
            this.panel3.Location = new System.Drawing.Point(0, -1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(952, 57);
            this.panel3.TabIndex = 0;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // label4
            // 
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.Location = new System.Drawing.Point(320, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(249, 57);
            this.label4.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
            this.label6.Location = new System.Drawing.Point(1, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 57);
            this.label6.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
            this.label5.Location = new System.Drawing.Point(13, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 15);
            this.label5.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(77, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 38);
            this.label1.TabIndex = 8;
            // 
            // min
            // 
            this.min.Image = global::notesbooks.Properties.Resources.最小化;
            this.min.Location = new System.Drawing.Point(838, 3);
            this.min.Name = "min";
            this.min.Size = new System.Drawing.Size(33, 21);
            this.min.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.min.TabIndex = 7;
            this.min.TabStop = false;
            this.min.Click += new System.EventHandler(this.min_Click);
            this.min.MouseClick += new System.Windows.Forms.MouseEventHandler(this.max_MouseClick);
            // 
            // max
            // 
            this.max.Image = global::notesbooks.Properties.Resources.最大化;
            this.max.Location = new System.Drawing.Point(877, 3);
            this.max.Name = "max";
            this.max.Size = new System.Drawing.Size(33, 21);
            this.max.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.max.TabIndex = 6;
            this.max.TabStop = false;
            this.max.MouseClick += new System.Windows.Forms.MouseEventHandler(this.max_MouseClick);
            // 
            // close
            // 
            this.close.Image = global::notesbooks.Properties.Resources.close1;
            this.close.Location = new System.Drawing.Point(916, 5);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(25, 18);
            this.close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.close.TabIndex = 0;
            this.close.TabStop = false;
            this.close.Click += new System.EventHandler(this.close_Click_1);
            this.close.MouseEnter += new System.EventHandler(this.close_MouseEnter);
            this.close.MouseLeave += new System.EventHandler(this.close_MouseLeave);
            // 
            // NewMenu
            // 
            this.NewMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.NewMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.NewMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiNew,
            this.桌面便签,
            this.MarkDown笔记,
            this.分类,
            this.我的日记,
            this.会议记录,
            this.工作日志,
            this.九宫格日志,
            this.客户拜访日记,
            this.工作周报,
            this.更多模板});
            this.NewMenu.Name = "新建笔记";
            this.NewMenu.ShowImageMargin = false;
            this.NewMenu.Size = new System.Drawing.Size(159, 230);
            this.NewMenu.Text = "新建笔记";
            // 
            // tsmiNew
            // 
            this.tsmiNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tsmiNew.Name = "tsmiNew";
            this.tsmiNew.Size = new System.Drawing.Size(158, 22);
            this.tsmiNew.Text = "新建笔记";
            this.tsmiNew.Click += new System.EventHandler(this.tsmiNew_Click);
            // 
            // 桌面便签
            // 
            this.桌面便签.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.桌面便签.Name = "桌面便签";
            this.桌面便签.Size = new System.Drawing.Size(158, 22);
            this.桌面便签.Text = "桌面便签";
            // 
            // MarkDown笔记
            // 
            this.MarkDown笔记.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.MarkDown笔记.Name = "MarkDown笔记";
            this.MarkDown笔记.Size = new System.Drawing.Size(158, 22);
            this.MarkDown笔记.Text = "MarkDown笔记";
            // 
            // 分类
            // 
            this.分类.Name = "分类";
            this.分类.Size = new System.Drawing.Size(155, 6);
            // 
            // 我的日记
            // 
            this.我的日记.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.我的日记.Name = "我的日记";
            this.我的日记.Size = new System.Drawing.Size(158, 22);
            this.我的日记.Text = "我的日记";
            // 
            // 会议记录
            // 
            this.会议记录.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.会议记录.Name = "会议记录";
            this.会议记录.Size = new System.Drawing.Size(158, 22);
            this.会议记录.Text = "会议记录";
            // 
            // 工作日志
            // 
            this.工作日志.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.工作日志.Name = "工作日志";
            this.工作日志.Size = new System.Drawing.Size(158, 22);
            this.工作日志.Text = "工作日志";
            // 
            // 九宫格日志
            // 
            this.九宫格日志.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.九宫格日志.Name = "九宫格日志";
            this.九宫格日志.Size = new System.Drawing.Size(158, 22);
            this.九宫格日志.Text = "九宫格日志";
            // 
            // 客户拜访日记
            // 
            this.客户拜访日记.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.客户拜访日记.Name = "客户拜访日记";
            this.客户拜访日记.Size = new System.Drawing.Size(158, 22);
            this.客户拜访日记.Text = "客户拜访日记";
            // 
            // 工作周报
            // 
            this.工作周报.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.工作周报.Name = "工作周报";
            this.工作周报.Size = new System.Drawing.Size(158, 22);
            this.工作周报.Text = "工作周报";
            // 
            // 更多模板
            // 
            this.更多模板.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.更多模板.Name = "更多模板";
            this.更多模板.Size = new System.Drawing.Size(158, 22);
            this.更多模板.Text = "更多模板";
            // 
            // treeView1
            // 
            this.treeView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.treeView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeView1.ImageIndex = 1;
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Location = new System.Drawing.Point(7, 241);
            this.treeView1.Name = "treeView1";
            treeNode1.BackColor = System.Drawing.Color.Transparent;
            treeNode1.ImageIndex = 0;
            treeNode1.Name = "节点1";
            treeNode1.Text = "提到我的消息";
            treeNode2.BackColor = System.Drawing.Color.Transparent;
            treeNode2.ImageIndex = 10;
            treeNode2.Name = "节点2";
            treeNode2.Text = "笔记被修改的消息";
            treeNode3.BackColor = System.Drawing.Color.Transparent;
            treeNode3.ImageIndex = 6;
            treeNode3.Name = "节点3";
            treeNode3.Text = "评论消息";
            treeNode4.BackColor = System.Drawing.Color.Transparent;
            treeNode4.ImageIndex = 2;
            treeNode4.Name = "节点4";
            treeNode4.Text = "我发出的消息";
            treeNode5.BackColor = System.Drawing.Color.Transparent;
            treeNode5.ImageIndex = 9;
            treeNode5.Name = "节点0";
            treeNode5.Text = "消息中心";
            treeNode6.ForeColor = System.Drawing.Color.DarkGray;
            treeNode6.Name = "节点7";
            treeNode6.Text = "拖动笔记，文件夹，标签等加到快捷方式";
            treeNode7.ImageIndex = 4;
            treeNode7.Name = "节点5";
            treeNode7.Text = "快捷方式";
            treeNode8.ImageIndex = 5;
            treeNode8.Name = "节点9";
            treeNode8.Text = "快速搜索";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode7,
            treeNode8});
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.Size = new System.Drawing.Size(221, 174);
            this.treeView1.TabIndex = 1;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "@.ico");
            this.imageList1.Images.SetKeyName(1, "标签.ico");
            this.imageList1.Images.SetKeyName(2, "发出.ico");
            this.imageList1.Images.SetKeyName(3, "回收站.ico");
            this.imageList1.Images.SetKeyName(4, "快捷方式.ico");
            this.imageList1.Images.SetKeyName(5, "快速搜索.ico");
            this.imageList1.Images.SetKeyName(6, "评论.ico");
            this.imageList1.Images.SetKeyName(7, "文件夹.ico");
            this.imageList1.Images.SetKeyName(8, "我的笔记.ico");
            this.imageList1.Images.SetKeyName(9, "消息中心.ico");
            this.imageList1.Images.SetKeyName(10, "修改.ico");
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.treeView);
            this.panel1.Controls.Add(this.treeView11);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.treeView1);
            this.panel1.Location = new System.Drawing.Point(0, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(231, 648);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // treeView
            // 
            this.treeView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.treeView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeView.ContextMenuStrip = this.NEWmenu2;
            this.treeView.ImageIndex = 8;
            this.treeView.ImageList = this.imageList1;
            this.treeView.Location = new System.Drawing.Point(7, 166);
            this.treeView.Name = "treeView";
            treeNode9.Checked = true;
            treeNode9.ContextMenuStrip = this.NEWmenu2;
            treeNode9.ImageIndex = 8;
            treeNode9.Name = "节点0";
            treeNode9.Text = "我的文件";
            treeNode10.Checked = true;
            treeNode10.ContextMenuStrip = this.NEWmenu2;
            treeNode10.ImageIndex = 8;
            treeNode10.Name = "节点1";
            treeNode10.Text = "其他";
            treeNode11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            treeNode11.Checked = true;
            treeNode11.ContextMenuStrip = this.classify;
            treeNode11.ImageIndex = 7;
            treeNode11.Name = "文件夹";
            treeNode11.Text = "文件夹";
            this.treeView.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode11});
            this.treeView.SelectedImageIndex = 0;
            this.treeView.Size = new System.Drawing.Size(198, 33);
            this.treeView.TabIndex = 0;
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            this.treeView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseDown);
            this.treeView.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeView_MouseUp);
            // 
            // treeView11
            // 
            this.treeView11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.treeView11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeView11.ContextMenuStrip = this.classify;
            this.treeView11.ImageIndex = 0;
            this.treeView11.ImageList = this.imageList1;
            this.treeView11.Location = new System.Drawing.Point(12, 36);
            this.treeView11.Name = "treeView11";
            treeNode12.ContextMenuStrip = this.NEWmenu2;
            treeNode12.ImageIndex = 8;
            treeNode12.Name = "我的笔记";
            treeNode12.Text = "我的笔记";
            treeNode13.ImageIndex = 8;
            treeNode13.Name = "节点2";
            treeNode13.Text = "我的草稿";
            treeNode14.ImageIndex = 3;
            treeNode14.Name = "节点3";
            treeNode14.Text = "回收站";
            treeNode15.ImageIndex = 7;
            treeNode15.Name = "节点0";
            treeNode15.Text = "文件夹";
            treeNode16.ImageIndex = 1;
            treeNode16.Name = "节点4";
            treeNode16.Text = "标签";
            this.treeView11.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode15,
            treeNode16});
            this.treeView11.SelectedImageIndex = 0;
            this.treeView11.Size = new System.Drawing.Size(198, 110);
            this.treeView11.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label3.Location = new System.Drawing.Point(4, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "个人笔记";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(13, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "常用";
            // 
            // rtxtNotepad
            // 
            this.rtxtNotepad.Location = new System.Drawing.Point(8, 95);
            this.rtxtNotepad.Name = "rtxtNotepad";
            this.rtxtNotepad.Size = new System.Drawing.Size(688, 529);
            this.rtxtNotepad.TabIndex = 4;
            this.rtxtNotepad.Text = "";
            this.rtxtNotepad.TextChanged += new System.EventHandler(this.rtxtNotepad_TextChanged);
            // 
            // tsmiSave
            // 
            this.tsmiSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.tsmiSave.FlatAppearance.BorderSize = 0;
            this.tsmiSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tsmiSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmiSave.Location = new System.Drawing.Point(8, 3);
            this.tsmiSave.Name = "tsmiSave";
            this.tsmiSave.Size = new System.Drawing.Size(105, 31);
            this.tsmiSave.TabIndex = 2;
            this.tsmiSave.Text = "保存";
            this.tsmiSave.UseVisualStyleBackColor = false;
            this.tsmiSave.Click += new System.EventHandler(this.tsmiSave_Click);
            // 
            // sdlgNotepad
            // 
            this.sdlgNotepad.FileName = "无标题";
            this.sdlgNotepad.Filter = "RTF文件|*.rtf";
            this.sdlgNotepad.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // odlgNotepad
            // 
            this.odlgNotepad.FileName = "openFileDialog1";
            this.odlgNotepad.Filter = "RTF文件|*.rtf|所有文件|*.*";
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.tsmiOpen);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.tlsNotepad);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.rtxtNotepad);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.tsmiSave);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(773, 638);
            this.toolStripContainer1.Location = new System.Drawing.Point(237, 62);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(773, 663);
            this.toolStripContainer1.TabIndex = 4;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // tsmiOpen
            // 
            this.tsmiOpen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.tsmiOpen.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(252)))));
            this.tsmiOpen.FlatAppearance.BorderSize = 0;
            this.tsmiOpen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tsmiOpen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsmiOpen.Location = new System.Drawing.Point(144, 2);
            this.tsmiOpen.Name = "tsmiOpen";
            this.tsmiOpen.Size = new System.Drawing.Size(100, 32);
            this.tsmiOpen.TabIndex = 6;
            this.tsmiOpen.Text = "打开";
            this.tsmiOpen.UseVisualStyleBackColor = false;
            this.tsmiOpen.Click += new System.EventHandler(this.tsmiOpen_Click);
            // 
            // tlsNotepad
            // 
            this.tlsNotepad.Dock = System.Windows.Forms.DockStyle.None;
            this.tlsNotepad.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.tlsNotepad.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Open,
            this.tsmiSaveAs,
            this.tsmiCut,
            this.tsmiCopy,
            this.tsmiPaste,
            this.toolStripSeparator1,
            this.tsmiUndo,
            this.tsmiRedo,
            this.tsmiFont,
            this.toolStripSeparator2,
            this.粗体,
            this.Italic,
            this.underline,
            this.toolStripSeparator3,
            this.toolStripSeparator4,
            this.Backgroundclr,
            this.tsmiSelectAll,
            this.tsmiAuto});
            this.tlsNotepad.Location = new System.Drawing.Point(6, 64);
            this.tlsNotepad.Name = "tlsNotepad";
            this.tlsNotepad.Size = new System.Drawing.Size(349, 25);
            this.tlsNotepad.TabIndex = 5;
            this.tlsNotepad.Text = "toolStrip1";
            this.tlsNotepad.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.tlsNotepad_ItemClicked);
            // 
            // Open
            // 
            this.Open.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Open.Image = ((System.Drawing.Image)(resources.GetObject("Open.Image")));
            this.Open.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Open.Name = "Open";
            this.Open.Size = new System.Drawing.Size(23, 22);
            this.Open.Text = "打开(&O)";
            this.Open.Click += new System.EventHandler(this.Open_Click);
            // 
            // tsmiSaveAs
            // 
            this.tsmiSaveAs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsmiSaveAs.Image = ((System.Drawing.Image)(resources.GetObject("tsmiSaveAs.Image")));
            this.tsmiSaveAs.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmiSaveAs.Name = "tsmiSaveAs";
            this.tsmiSaveAs.Size = new System.Drawing.Size(23, 22);
            this.tsmiSaveAs.Text = "另存为(&S)";
            this.tsmiSaveAs.Click += new System.EventHandler(this.tsmiSaveAs_Click);
            // 
            // tsmiCut
            // 
            this.tsmiCut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsmiCut.Image = ((System.Drawing.Image)(resources.GetObject("tsmiCut.Image")));
            this.tsmiCut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmiCut.Name = "tsmiCut";
            this.tsmiCut.Size = new System.Drawing.Size(23, 22);
            this.tsmiCut.Text = "剪切(&U)";
            this.tsmiCut.Click += new System.EventHandler(this.tsmiCut_Click);
            // 
            // tsmiCopy
            // 
            this.tsmiCopy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsmiCopy.Image = ((System.Drawing.Image)(resources.GetObject("tsmiCopy.Image")));
            this.tsmiCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmiCopy.Name = "tsmiCopy";
            this.tsmiCopy.Size = new System.Drawing.Size(23, 22);
            this.tsmiCopy.Text = "复制(&C)";
            this.tsmiCopy.Click += new System.EventHandler(this.tsmiCopy_Click_1);
            // 
            // tsmiPaste
            // 
            this.tsmiPaste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsmiPaste.Image = ((System.Drawing.Image)(resources.GetObject("tsmiPaste.Image")));
            this.tsmiPaste.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmiPaste.Name = "tsmiPaste";
            this.tsmiPaste.Size = new System.Drawing.Size(23, 22);
            this.tsmiPaste.Text = "粘贴(&P)";
            this.tsmiPaste.Click += new System.EventHandler(this.tsmiPaste_Click_1);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tsmiUndo
            // 
            this.tsmiUndo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsmiUndo.Image = global::notesbooks.Properties.Resources.左撤销;
            this.tsmiUndo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmiUndo.Name = "tsmiUndo";
            this.tsmiUndo.Size = new System.Drawing.Size(23, 22);
            this.tsmiUndo.Text = "s1";
            // 
            // tsmiRedo
            // 
            this.tsmiRedo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsmiRedo.Image = global::notesbooks.Properties.Resources.右撤销;
            this.tsmiRedo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmiRedo.Name = "tsmiRedo";
            this.tsmiRedo.Size = new System.Drawing.Size(23, 22);
            this.tsmiRedo.Text = "toolStripButton1";
            this.tsmiRedo.Click += new System.EventHandler(this.tsmiRedo_Click);
            // 
            // tsmiFont
            // 
            this.tsmiFont.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsmiFont.Image = global::notesbooks.Properties.Resources.字体;
            this.tsmiFont.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmiFont.Name = "tsmiFont";
            this.tsmiFont.Size = new System.Drawing.Size(23, 22);
            this.tsmiFont.Click += new System.EventHandler(this.tsmiFont_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // 粗体
            // 
            this.粗体.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.粗体.Image = global::notesbooks.Properties.Resources.加粗;
            this.粗体.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.粗体.Name = "粗体";
            this.粗体.Size = new System.Drawing.Size(23, 22);
            this.粗体.Text = "加粗";
            this.粗体.Click += new System.EventHandler(this.Bold_Click);
            // 
            // Italic
            // 
            this.Italic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Italic.Image = global::notesbooks.Properties.Resources.斜体;
            this.Italic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Italic.Name = "Italic";
            this.Italic.Size = new System.Drawing.Size(23, 22);
            this.Italic.Text = "斜体";
            this.Italic.Click += new System.EventHandler(this.Italic_Click);
            // 
            // underline
            // 
            this.underline.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.underline.Image = global::notesbooks.Properties.Resources.加下划线;
            this.underline.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.underline.Name = "underline";
            this.underline.Size = new System.Drawing.Size(23, 22);
            this.underline.Text = "toolStripButton3";
            this.underline.ToolTipText = "下划线";
            this.underline.Click += new System.EventHandler(this.underline_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // Backgroundclr
            // 
            this.Backgroundclr.Checked = true;
            this.Backgroundclr.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Backgroundclr.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Backgroundclr.Image = global::notesbooks.Properties.Resources.背景颜色;
            this.Backgroundclr.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Backgroundclr.Name = "Backgroundclr";
            this.Backgroundclr.Size = new System.Drawing.Size(23, 22);
            this.Backgroundclr.Text = "背景颜色";
            this.Backgroundclr.Click += new System.EventHandler(this.Backgroundclr_Click);
            // 
            // tsmiSelectAll
            // 
            this.tsmiSelectAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsmiSelectAll.Image = global::notesbooks.Properties.Resources.全选;
            this.tsmiSelectAll.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmiSelectAll.Name = "tsmiSelectAll";
            this.tsmiSelectAll.Size = new System.Drawing.Size(23, 22);
            this.tsmiSelectAll.Text = "全选";
            this.tsmiSelectAll.Click += new System.EventHandler(this.tsmiSelectAll_Click);
            // 
            // tsmiAuto
            // 
            this.tsmiAuto.Checked = true;
            this.tsmiAuto.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsmiAuto.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsmiAuto.Image = global::notesbooks.Properties.Resources.换行;
            this.tsmiAuto.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsmiAuto.Name = "tsmiAuto";
            this.tsmiAuto.Size = new System.Drawing.Size(23, 22);
            this.tsmiAuto.Text = "自动换行";
            this.tsmiAuto.Click += new System.EventHandler(this.tsmiAuto_Click);
            // 
            // colorDialog1
            // 
            this.colorDialog1.AnyColor = true;
            this.colorDialog1.FullOpen = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label7.Location = new System.Drawing.Point(9, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 15);
            this.label7.TabIndex = 5;
            this.label7.Text = "打开";
            // 
            // Notes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 727);
            this.Controls.Add(this.toolStripContainer1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Notes";
            this.Text = "Notes";
            this.Load += new System.EventHandler(this.Notes_Load);
            this.NEWmenu2.ResumeLayout(false);
            this.classify.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.min)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.max)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.close)).EndInit();
            this.NewMenu.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ContentPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.tlsNotepad.ResumeLayout(false);
            this.tlsNotepad.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox close;
        private System.Windows.Forms.PictureBox max;
        private System.Windows.Forms.PictureBox min;
        private System.Windows.Forms.ContextMenuStrip NewMenu;
        private System.Windows.Forms.ToolStripMenuItem tsmiNew;
        private System.Windows.Forms.ToolStripMenuItem 桌面便签;
        private System.Windows.Forms.ToolStripMenuItem MarkDown笔记;
        private System.Windows.Forms.ToolStripSeparator 分类;
        private System.Windows.Forms.ToolStripMenuItem 我的日记;
        private System.Windows.Forms.ToolStripMenuItem 会议记录;
        private System.Windows.Forms.ToolStripMenuItem 工作日志;
        private System.Windows.Forms.ToolStripMenuItem 九宫格日志;
        private System.Windows.Forms.ToolStripMenuItem 客户拜访日记;
        private System.Windows.Forms.ToolStripMenuItem 工作周报;
        private System.Windows.Forms.ToolStripMenuItem 更多模板;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TreeView treeView11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button tsmiSave;
        private System.Windows.Forms.RichTextBox rtxtNotepad;
        private System.Windows.Forms.SaveFileDialog sdlgNotepad;
        private System.Windows.Forms.OpenFileDialog odlgNotepad;
        private System.Windows.Forms.FontDialog fdlgNotepad;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStrip tlsNotepad;
        private System.Windows.Forms.ToolStripButton Open;
        private System.Windows.Forms.ToolStripButton tsmiSaveAs;
        private System.Windows.Forms.ToolStripButton tsmiCut;
        private System.Windows.Forms.ToolStripButton tsmiCopy;
        private System.Windows.Forms.ToolStripButton tsmiPaste;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsmiUndo;
        private System.Windows.Forms.ToolStripButton tsmiRedo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton 粗体;
        private System.Windows.Forms.ToolStripButton Italic;
        private System.Windows.Forms.ToolStripButton underline;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton tsmiSelectAll;
        private System.Windows.Forms.Button tsmiOpen;
        private System.Windows.Forms.ToolStripButton tsmiFont;
        private System.Windows.Forms.ToolStripButton tsmiAuto;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripButton Backgroundclr;
        private System.Windows.Forms.ContextMenuStrip classify;
        private System.Windows.Forms.ToolStripMenuItem 新建分类;
        private System.Windows.Forms.ToolStripMenuItem 修改分类;
        private System.Windows.Forms.ToolStripMenuItem 删除分类;
        private System.Windows.Forms.ContextMenuStrip NEWmenu2;
        private System.Windows.Forms.ToolStripMenuItem 新建;
        private System.Windows.Forms.ToolStripMenuItem 删除;
        private System.Windows.Forms.ToolStripMenuItem 重命名;
        private System.Windows.Forms.ToolStripMenuItem 移动到ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 打开ToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.Label label7;


    }
}