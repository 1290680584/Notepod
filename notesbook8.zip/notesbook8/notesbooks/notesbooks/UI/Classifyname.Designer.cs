﻿namespace notesbooks
{
    partial class Classifyname
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.clfname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.确定 = new System.Windows.Forms.Button();
            this.取消 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // clfname
            // 
            this.clfname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.clfname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.clfname.Location = new System.Drawing.Point(154, 48);
            this.clfname.Multiline = true;
            this.clfname.Name = "clfname";
            this.clfname.Size = new System.Drawing.Size(242, 31);
            this.clfname.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(57, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "新建分类:";
            // 
            // 确定
            // 
            this.确定.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.确定.FlatAppearance.BorderSize = 0;
            this.确定.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.确定.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.确定.Location = new System.Drawing.Point(270, 118);
            this.确定.Name = "确定";
            this.确定.Size = new System.Drawing.Size(75, 36);
            this.确定.TabIndex = 2;
            this.确定.Text = "确定";
            this.确定.UseVisualStyleBackColor = false;
            this.确定.Click += new System.EventHandler(this.确定_Click);
            // 
            // 取消
            // 
            this.取消.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(125)))), ((int)(((byte)(255)))));
            this.取消.FlatAppearance.BorderSize = 0;
            this.取消.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.取消.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.取消.Location = new System.Drawing.Point(351, 118);
            this.取消.Name = "取消";
            this.取消.Size = new System.Drawing.Size(75, 36);
            this.取消.TabIndex = 3;
            this.取消.Text = "取消";
            this.取消.UseVisualStyleBackColor = false;
            this.取消.Click += new System.EventHandler(this.取消_Click);
            // 
            // Classifyname
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 166);
            this.Controls.Add(this.取消);
            this.Controls.Add(this.确定);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.clfname);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Classifyname";
            this.Text = "新建分类";
            this.Load += new System.EventHandler(this.Classifyname_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox clfname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button 确定;
        private System.Windows.Forms.Button 取消;
    }
}