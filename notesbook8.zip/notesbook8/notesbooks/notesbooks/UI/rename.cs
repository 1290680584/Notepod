﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace notesbooks
{
    public partial class rename : Form
    {
        string path;
        string olddir;
        string oldname;
        public rename(string path,string olddir,string oldname)
        {
            this.path = path;
            this.olddir = olddir;
            this.oldname = oldname;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                string newname = textBox2.Text;
                if (olddir != "")
                    olddir += "//";
                try
                {
                    File.Move(path + "//" + olddir + oldname, path + "//" + olddir + newname);
                }
                catch (Exception ee)
                {
                    DirectoryInfo di = new DirectoryInfo(path + "//" + olddir + oldname);
                    int i = 0;
                    while(true)
                    {
                        if (i == 0)
                        {
                            if(!Directory.Exists(path + "//" + olddir + newname))
                            {
                                di.MoveTo(path + "//" + olddir + newname);
                                break;
                            }
                        }
                        else
                        {
                            if (!Directory.Exists(path + "//" + olddir + newname+"("+i+")"))
                            {
                                di.MoveTo(path + "//" + olddir + newname + "(" + i + ")");
                                break;
                            }
                        }
                        i++;
                    }
                }
                this.Close();
            }
            else
                MessageBox.Show("请输入新的文件名");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void rename_Load(object sender, EventArgs e)
        {

        }

    }
}

