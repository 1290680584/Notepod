﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;



namespace notesbooks
{
    public partial class Classifyname : Form
    {
        public Classifyname()
        {
            InitializeComponent();
        }

        private void 确定_Click(object sender, EventArgs e)
        {
                //string Directory;
             string path = "C:\\Users\\Administrator\\Desktop\\Note\\" + clfname.Text;
                Directory.CreateDirectory(path); //CreateDirectory(string path);
                DirectoryInfo dir = new DirectoryInfo(path);
                this.Close();
                //dir.Create();//自行判断一下是否存在。  
                //MessageBox.Show("已存在");
                //如果是创建子文件夹  
                //DirectoryInfo dir = new DirectoryInfo(path);  
                //dir.CreateSubdirectory(string subFolderName);  
        }

        private void 取消_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Classifyname_Load(object sender, EventArgs e)
        {

        }
}
}